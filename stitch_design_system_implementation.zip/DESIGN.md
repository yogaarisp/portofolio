---
name: Yoga Aris Purwanto Portfolio Design System
colors:
  surface: '#f5faf8'
  surface-dim: '#d6dbd9'
  surface-bright: '#f5faf8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f0f5f2'
  surface-container: '#eaefed'
  surface-container-high: '#e4e9e7'
  surface-container-highest: '#dee4e1'
  on-surface: '#171d1c'
  on-surface-variant: '#3d4947'
  inverse-surface: '#2c3130'
  inverse-on-surface: '#edf2f0'
  outline: '#6d7a77'
  outline-variant: '#bcc9c6'
  surface-tint: '#006a61'
  primary: '#00685f'
  on-primary: '#ffffff'
  primary-container: '#008378'
  on-primary-container: '#f4fffc'
  inverse-primary: '#6bd8cb'
  secondary: '#735c00'
  on-secondary: '#ffffff'
  secondary-container: '#fed65b'
  on-secondary-container: '#745c00'
  tertiary: '#924628'
  on-tertiary: '#ffffff'
  tertiary-container: '#b05e3d'
  on-tertiary-container: '#fffbff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#89f5e7'
  primary-fixed-dim: '#6bd8cb'
  on-primary-fixed: '#00201d'
  on-primary-fixed-variant: '#005049'
  secondary-fixed: '#ffe088'
  secondary-fixed-dim: '#e9c349'
  on-secondary-fixed: '#241a00'
  on-secondary-fixed-variant: '#574500'
  tertiary-fixed: '#ffdbce'
  tertiary-fixed-dim: '#ffb59a'
  on-tertiary-fixed: '#370e00'
  on-tertiary-fixed-variant: '#773215'
  background: '#f5faf8'
  on-background: '#171d1c'
  surface-variant: '#dee4e1'
  accent-maroon: '#7F1D1D'
  bg-light: '#F8FAFC'
  bg-dark: '#0F172A'
  surface-teal-dim: '#0F766E'
  text-primary: '#1E293B'
  text-muted: '#64748B'
typography:
  h1:
    fontFamily: Manrope
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  h2:
    fontFamily: Manrope
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.3'
    letterSpacing: -0.01em
  h3:
    fontFamily: Manrope
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1'
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  base: 8px
  section-gap: 80px
  card-padding: 24px
  container-max: 1200px
  gutter: 24px
---

# Dokumen Desain Portofolio Profesional: Yoga Aris Purwanto

Dokumen ini berisi spesifikasi teknis, konten, dan panduan visual untuk pembangunan website portofolio profesional.

## 1. Profil Utama
* **Nama:** Yoga Aris Purwanto
* **Peran:** IT Specialist (Infrastructure, Network, & Software Development)
* **Tagline:** Bridging Infrastructure and Innovation.
* **Ringkasan Karier:** Teknisi komputer yang berdedikasi dengan fokus pada eksplorasi kemampuan teknis dan kepemimpinan. Memiliki rekam jejak yang kuat mulai dari IT Helpdesk, IT Support, hingga IT Infrastructure. Terbukti mampu memimpin tim (Leader/Coordinator) dan mengelola proyek IT kompleks dari sisi perangkat keras maupun perangkat lunak.

---

## 2. Spesifikasi Teknis (Tech Stack)
Direkomendasikan menggunakan stack berikut untuk kemudahan manajemen di aaPanel:
* **Backend:** Laravel 11 (PHP 8.2+)
* **Frontend:** Tailwind CSS (Vite)
* **Interaktivitas:** Livewire 3 / Alpine.js
* **Database:** MySQL / MariaDB
* **Server Management:** aaPanel (VPS Hosting)

---

## 3. Keahlian Profesional (Core Competencies)

### Infrastructure & Network
* Troubleshooting & Instalasi CCTV (Analog & IP)
* Konfigurasi Mikrotik (Routing, Bandwidth Management)
* Windows Server Administration
* Instalasi & Perbaikan Komputer/Laptop
* Pengadaan Laboratorium IT

### Software Development
* Web Development (Laravel, Next.js)
* Automation Testing
* Analisis & Evaluasi Sistem
* API Integration (Supabase, Firebase)

### Leadership & Creative
* IT Mentoring & Training
* Reporting & Documentation
* Project Coordination (IT Support/Helpdesk Lead)
* Video Content Creation

---

## 4. Riwayat Pengalaman Kerja

### Freelancer (2023 - Sekarang)
* Maintenance Jaringan, PC, Laptop, & CCTV.
* Pengadaan Lab IT & Web Developer.

### PT Permodalan Nasional Madani (PNM) (2022) - Staff IT
* Ticketing System, Instalasi Device, Support Event PKU/SDM.

### All Stay Hotel Semarang (2022) - Staff IT
* Maintenance Jaringan Hotel & Support Direksi.

### PT Ungaran Sari Garments (USG) (2019 - 2022) - IT Helpdesk + IT Support (Coordinator)
* Koordinator All Unit, Trainer IT Support, JIRA Management.

### Busana Apparel Group (2018 - 2019) - IT Support
* Mikrotik Configuration, Mail Server, Support VVIP User.

---

## 5. Panduan Visual & UI/UX (Prompts)

### Konsep Desain
* **Style:** Curved Modern (Border radius besar: 16px - 24px).
* **Vibe:** Professional, Clean, Tech-Savvy.
* **Palet Warna:**
    * Primary: Deep Teal (`#0D9488`)
    * Accent: Gold (`#D4AF37`) atau Maroon (`#7F1D1D`) untuk badge penting.
    * Background: White Smoke (`#F8FAFC`) untuk Light Mode atau Slate Dark (`#0F172A`) untuk Dark Mode.

### AI Image Generator Prompt (DALL-E/Midjourney)
> "Professional IT portfolio website design for 'Yoga Aris Purwanto'. Modern Corporate Tech aesthetic with Curved UI. Primary color: Deep Teal, accents: Gold. Minimalist 3D isometric illustration of servers and code. Card-based layout with high border-radius. Clean, 4k, responsive web design."

---

## 6. Rencana Deployment (aaPanel)
1.  **Site Directory:** Arahkan ke `/public`.
2.  **URL Rewrite:** Pilih template **laravel**.
3.  **PHP Version:** Gunakan PHP 8.2 atau lebih baru.
4.  **SSL:** Aktifkan Let's Encrypt (HTTPS).
5.  **Optimization:** Jalankan `php artisan optimize` setelah deploy.

---

*Dibuat oleh: Yoga Aris Purwanto*
*Terakhir diupdate: April 2026*
